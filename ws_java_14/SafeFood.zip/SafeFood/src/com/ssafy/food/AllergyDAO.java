package com.ssafy.food;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class AllergyDAO {
	List<String> allergy = new ArrayList<>();
	
	public void open() {
		ObjectInputStream ois = null;
		File file = new File("alg.dat");
		if(!file.exists()) {return;}
		allergy.clear();
		try {
			ois = new ObjectInputStream(new FileInputStream(file));
			String str ="";
			while(true) {
				str = (String) ois.readObject();
				allergy.add(str);
				System.out.println(allergy);
			}
		} catch (IOException e) {
		} catch (ClassNotFoundException e) {
		}finally {
			if(ois!=null)
				try {
					ois.close();
				} catch (IOException e) {
				}
		}
	}
	public void close() throws Exception {
		File file = new File("alg.dat");
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		for(String a : allergy) {
			oos.writeObject(a);
			oos.flush();
		}
		oos.close();
		fos.close();
	}
	public void addAllergy(String str) {
		allergy.add(str);
	}
	public List<String> allAllergy(){
		return allergy;
	}
	public void removeAllergy(String str) {
		allergy.remove(str);
	}
}
