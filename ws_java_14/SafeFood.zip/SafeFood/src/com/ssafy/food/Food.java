package com.ssafy.food;

public class Food {
	private String prdlstNm;
	private String rawmtrl;
	private String allergy;
	private String nutrient;
	private String prdkind;
	private String manufacture;
	private String imgurl1;

	
	public Food() {
		super();
	}

	public Food(String prdlstNm, String rawmtrl, String allergy, String nutrient, String prdkind, String manufacture,
			String imgurl1) {
		super();
		this.prdlstNm = prdlstNm;
		this.rawmtrl = rawmtrl;
		this.allergy = allergy;
		this.nutrient = nutrient;
		this.prdkind = prdkind;
		this.manufacture = manufacture;
		this.imgurl1 = imgurl1;
	}

	public String getPrdlstNm() {
		return prdlstNm;
	}

	public void setPrdlstNm(String prdlstNm) {
		this.prdlstNm = prdlstNm;
	}

	public String getRawmtrl() {
		return rawmtrl;
	}

	public void setRawmtrl(String rawmtrl) {
		this.rawmtrl = rawmtrl;
	}

	public String getAllergy() {
		return allergy;
	}

	public void setAllergy(String allergy) {
		this.allergy = allergy;
	}

	public String getNutrient() {
		return nutrient;
	}

	public void setNutrient(String nutrient) {
		this.nutrient = nutrient;
	}

	public String getPrdkind() {
		return prdkind;
	}

	public void setPrdkind(String prdkind) {
		this.prdkind = prdkind;
	}

	public String getManufacture() {
		return manufacture;
	}

	public void setManufacture(String manufacture) {
		this.manufacture = manufacture;
	}

	public String getImgurl1() {
		return imgurl1;
	}

	public void setImgurl1(String imgurl1) {
		this.imgurl1 = imgurl1;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		
		builder.append(prdlstNm);
		builder.append("     ");
		builder.append(rawmtrl);
		builder.append("     ");
		builder.append(allergy);
		builder.append("     ");
		builder.append(nutrient);
		builder.append("     ");
		builder.append(prdkind);
		builder.append("     ");
		builder.append(manufacture);
		builder.append("     ");
		builder.append(imgurl1);
		
		return builder.toString();
		
	}
	
}
