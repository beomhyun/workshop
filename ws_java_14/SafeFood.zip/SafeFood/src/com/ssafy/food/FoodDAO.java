package com.ssafy.food;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import javax.xml.crypto.Data;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class FoodDAO {
	List<Food> list =new ArrayList<>();
	AllergyDAO aldao = new AllergyDAO();
	
	public List<Food> open() {
		aldao.open();
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = null;
		String fname = "DATA.xml";
		try {
			db = dbf.newDocumentBuilder();
			Document doc = db.parse(fname);
			Element root = doc.getDocumentElement();
			NodeList items = root.getElementsByTagName("item");
			for (int i = 0; i < items.getLength(); i++) {
				Node item = items.item(i);
				if(item.getNodeType() == Node.ELEMENT_NODE) {
					Food food = new Food();
					NodeList noditems = item.getChildNodes();
					for (int j = 0; j < noditems.getLength(); j++) {
						Node noditem = noditems.item(j);
						if(noditem.getNodeName().equals("prdlstNm")) {
							food.setPrdlstNm((noditem.getFirstChild().getNodeValue()));
						}else if(noditem.getNodeName().equals("rawmtrl")) {
							food.setRawmtrl((noditem.getFirstChild().getNodeValue()));
						}else if(noditem.getNodeName().equals("allergy")) {
							food.setAllergy((noditem.getFirstChild().getNodeValue()));
						}else if(noditem.getNodeName().equals("nutrient")) {
							food.setNutrient((noditem.getFirstChild().getNodeValue()));
						}else if(noditem.getNodeName().equals("prdkind")) {
							food.setPrdkind((noditem.getFirstChild().getNodeValue()));
						}else if(noditem.getNodeName().equals("manufacture")) {
							food.setManufacture((noditem.getFirstChild().getNodeValue()));
						}else if(noditem.getNodeName().equals("imgurl1")) {
							food.setImgurl1((noditem.getFirstChild().getNodeValue()));
						}						
					}
					boolean check = false;
					for (int j = 0; j < aldao.allergy.size(); j++) {
						if(aldao.allergy.get(j).contains(food.getNutrient())) {
							check = true;
							break;
						}
					}
					if(check == false)list.add(food);
				}
			}
		} catch (ParserConfigurationException e) {
		} catch (SAXException e) {
		} catch (IOException e) {
		}
		return list;
	}
		public List<Food> searchbyna(String name){
			List<Food> ll =new ArrayList<>();
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getPrdlstNm().contains(name)) {
					ll.add(list.get(i));
				}
			}
			return ll;
		}
		public List<Food> searchbyco(String name){
			List<Food> ll =new ArrayList<>();
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getManufacture().contains(name)) {
					ll.add(list.get(i));
				}
			}
			return ll;
		}
		public List<Food> searchbynu(String name){
			List<Food> ll =new ArrayList<>();
			for (int i = 0; i < list.size(); i++) {
				if(list.get(i).getRawmtrl().contains(name)) {
					ll.add(list.get(i));
				}
			}
			return ll;
		}
		public List<Food> sortbyna(){
			List<Food> ll =new ArrayList<>();
			//list.sort((Food f1,Food f2)->f1.getPrdlstNm().compareTo(f2.getPrdlstNm()));
			list.sort(new Comparator<Food>() {
				@Override
				public int compare(Food o1, Food o2) {
					return o1.getPrdlstNm().compareTo(o2.getPrdlstNm());
				}
				
			});
			return ll;
		}
		public List<Food> sortbyco(){
			List<Food> ll =new ArrayList<>();
			list.sort((Food f1,Food f2)->f1.getManufacture().compareTo(f2.getPrdlstNm()));
			return ll;
		}
		public List<Food> sortbynu(){
			List<Food> ll =new ArrayList<>();
			list.sort((Food f1,Food f2)->f1.getPrdlstNm().compareTo(f2.getPrdlstNm()));
			return ll;
		}
}