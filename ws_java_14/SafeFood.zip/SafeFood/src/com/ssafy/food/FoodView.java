package com.ssafy.food;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JList;
import javax.swing.JPanel;

import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import java.awt.Color;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class FoodView {
	static FoodDAO dao;
	
	private JFrame frame;
	private JTextField textField;
	static JList list = new JList<>();
	List<Food> foodlist;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FoodView window = new FoodView();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FoodView() {
		initialize();
		dao = new FoodDAO();
		foodlist = dao.open();
		List<ViewFood> foodlistt = new ArrayList<>();
		for (int i = 0; i < foodlist.size(); i++) {
			foodlistt.add(new ViewFood(foodlist.get(i).getPrdlstNm()));
		}
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(22, 10, 400, 157);
		frame.getContentPane().add(scrollPane);
		
		scrollPane.setViewportView(list);
		list.setSelectedIndex(3);
		list.removeAll();
		list.setListData(foodlistt.toArray());
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 333);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(183, 176, 213, 21);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("제품명");
		rdbtnNewRadioButton.setBounds(22, 175, 121, 23);
		frame.getContentPane().add(rdbtnNewRadioButton);
		
		
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("제조사");
		rdbtnNewRadioButton_1.setBounds(22, 200, 121, 23);
		frame.getContentPane().add(rdbtnNewRadioButton_1);
		
		JRadioButton rdbtnNewRadioButton_2 = new JRadioButton("원재료");
		rdbtnNewRadioButton_2.setBounds(22, 225, 121, 23);
		frame.getContentPane().add(rdbtnNewRadioButton_2);
		
		ButtonGroup group = new ButtonGroup();
		group.add(rdbtnNewRadioButton);
		group.add(rdbtnNewRadioButton_1);
		group.add(rdbtnNewRadioButton_2);
		
		JButton btnNewButton = new JButton("정렬");
		btnNewButton.setBounds(303, 207, 97, 23);
		frame.getContentPane().add(btnNewButton);
		
		list.addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				if(!e.getValueIsAdjusting()) {
					for(Food food : foodlist) {
						if(list.getSelectedValue().toString().contains(food.getPrdlstNm())) {
							try {
								FoodView2 view2 = new FoodView2(food.getPrdlstNm(),food.getRawmtrl(),food.getAllergy(),food.getNutrient(),food.getPrdkind(),food.getManufacture(),food.getImgurl1());
							} catch (MalformedURLException e1) {
							} catch (IOException e1) {
							}
						}
					}
					
				}
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				List<Food> foodlist = new ArrayList<>();
				if(rdbtnNewRadioButton.isSelected()) {
					foodlist = dao.sortbyna();
				}else if(rdbtnNewRadioButton_1.isSelected()){
					foodlist = dao.sortbyco();
				}
				System.out.println(foodlist);
				List<ViewFood> foodlistt = new ArrayList<>();
				for (int i = 0; i < foodlist.size(); i++) {
					foodlistt.add(new ViewFood(foodlist.get(i).getPrdlstNm()));
				}
				list.removeAll();
				list.setListData(foodlistt.toArray());
			}
		});
		
		JButton btnNewButton_1 = new JButton("검색");
		btnNewButton_1.addActionListener(new ActionListener() {
			List<Food> foodlist = new ArrayList<>();

			public void actionPerformed(ActionEvent e) {
				if(rdbtnNewRadioButton.isSelected()) {
					foodlist = dao.searchbyna(textField.getText());
				}else if(rdbtnNewRadioButton_1.isSelected()){
					foodlist = dao.searchbyco(textField.getText());
				}else if(rdbtnNewRadioButton_2.isSelected()){
					foodlist = dao.searchbynu(textField.getText());
				}
				List<ViewFood> foodlistt = new ArrayList<>();
				for (int i = 0; i < foodlist.size(); i++) {
					foodlistt.add(new ViewFood(foodlist.get(i).getPrdlstNm()));
				}
				list.removeAll();
				list.setListData(foodlistt.toArray());
			}
		});
		
		btnNewButton_1.setBounds(183, 207, 97, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("알러지정보추가");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 FoodView3 ft =	new FoodView3();
			}
		});
		btnNewButton_2.setBounds(183, 238, 217, 23);
		frame.getContentPane().add(btnNewButton_2);
	}

	class newWindow extends JFrame {
	    // 버튼이 눌러지면 만들어지는 새 창을 정의한 클래스
	    newWindow() {
	        setTitle("새로 띄운 창");
	        // 주의, 여기서 setDefaultCloseOperation() 정의를 하지 말아야 한다
	        // 정의하게 되면 새 창을 닫으면 모든 창과 프로그램이 동시에 꺼진다
	        
	        JPanel NewWindowContainer = new JPanel();
	        setContentPane(NewWindowContainer);
	        
	        JLabel NewLabel = new JLabel("새 창을 띄우는데 성공!");
	        
	        NewWindowContainer.add(NewLabel);
	        
	        setSize(300,100);
	        setResizable(false);
	        setVisible(true);
	    }
	}
}
