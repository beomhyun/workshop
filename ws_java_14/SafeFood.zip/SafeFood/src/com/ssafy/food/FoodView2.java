package com.ssafy.food;

import java.awt.EventQueue;
import java.awt.HeadlessException;
import java.awt.Image;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

public class FoodView2 extends JFrame {
	
	private JLabel lblNewLabel = new JLabel();
	private JLabel lblNewLabel_1 = new JLabel();
	private JLabel lblNewLabel_2 = new JLabel();
	private JLabel lblNewLabel_3 = new JLabel();
	private JLabel lblNewLabel_4= new JLabel();;
	private JLabel lblNewLabel_5= new JLabel();;
	private JLabel lblNewLabel_6= new JLabel();;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 * @throws IOException 
	 */
    
	public FoodView2(String string, String string2, String string3, String string4, String string5,String string7, String string6) throws IOException {
		lblNewLabel.setText(string);
		lblNewLabel_1.setText(string2);
		lblNewLabel_2.setText(string3);
		lblNewLabel_3.setText(string4);
		lblNewLabel_4.setText(string5);
		lblNewLabel_5.setText(string7);
		URL url = new URL(string6);
		
		Image image = ImageIO.read(url);
		Image image2 = image.getScaledInstance(441, 187,Image.SCALE_SMOOTH);
        lblNewLabel_6.setIcon(new ImageIcon(image2));

		
	        setTitle("제품 정보");
	        // 주의, 여기서 setDefaultCloseOperation() 정의를 하지 말아야 한다
	        // 정의하게 되면 새 창을 닫으면 모든 창과 프로그램이 동시에 꺼진다
	        
	        JPanel NewWindowContainer = new JPanel();
	        setContentPane(NewWindowContainer);
	        NewWindowContainer.setLayout(null);
	        
	        JLabel label = new JLabel("상품명 : ");
	        label.setBounds(72, 207, 57, 15);
	        NewWindowContainer.add(label);
	        
	        JLabel label_1 = new JLabel("원재료 : ");
	        label_1.setBounds(72, 232, 57, 15);
	        NewWindowContainer.add(label_1);
	        
	        JLabel label_2 = new JLabel("알레르기 정보 : ");
	        label_2.setBounds(33, 257, 96, 15);
	        NewWindowContainer.add(label_2);
	        
	        JLabel label_3 = new JLabel("영양성분 : ");
	        label_3.setBounds(61, 282, 68, 15);
	        NewWindowContainer.add(label_3);
	        
	        JLabel label_4 = new JLabel("분류 : ");
	        label_4.setBounds(86, 307, 43, 15);
	        NewWindowContainer.add(label_4);
	        
	        JLabel label_5 = new JLabel("제조사 : ");
	        label_5.setBounds(75, 329, 54, 15);
	        NewWindowContainer.add(label_5);
	        
	        lblNewLabel.setBounds(141, 207, 312, 15);
	        NewWindowContainer.add(lblNewLabel);
	        
	        lblNewLabel_1.setBounds(141, 232, 312, 15);
	        NewWindowContainer.add(lblNewLabel_1);
	        
	        lblNewLabel_2.setBounds(141, 257, 312, 15);
	        NewWindowContainer.add(lblNewLabel_2);
	        
	        lblNewLabel_3.setBounds(141, 282, 312, 15);
	        NewWindowContainer.add(lblNewLabel_3);
	        
	        lblNewLabel_4.setBounds(141, 307, 312, 15);
	        NewWindowContainer.add(lblNewLabel_4);
	        
	        lblNewLabel_5.setBounds(141, 329, 312, 15);
	        NewWindowContainer.add(lblNewLabel_5);
	        
	        JPanel panel = new JPanel();
	        panel.setBounds(12, 10, 441, 187);
	        NewWindowContainer.add(panel);
	        panel.add(lblNewLabel_6);
	        
	        setSize(471,386);
	        setResizable(false);
	        setVisible(true);
	}
}
