package com.ssafy.food;
import java.awt.EventQueue;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FoodView3 extends JFrame {
	AllergyDAO alldao = new AllergyDAO();
	private JTextField textField;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JList list= new JList();;
	/**
	 * Launch the application.
	 */
	

	/**
	 * Create the application.
	 */
	public FoodView3() {
		 setTitle("새로 띄운 창");
	        // 주의, 여기서 setDefaultCloseOperation() 정의를 하지 말아야 한다
	        // 정의하게 되면 새 창을 닫으면 모든 창과 프로그램이 동시에 꺼진다
	        JPanel NewWindowContainer = new JPanel();
	        list.setBounds(39, 28, 344, 161);
	        NewWindowContainer.add(list);
	        open();
	        setContentPane(NewWindowContainer);
	        NewWindowContainer.setLayout(null);
	        btnNewButton = new JButton("삭제");
	        btnNewButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String str = textField.getText().trim();
	        		alldao.allergy.remove(str);
	        		try {
						alldao.close();
					} catch (Exception e1) {
					}
				}
				
			});
	        btnNewButton.setBounds(286, 199, 97, 23);
	        NewWindowContainer.add(btnNewButton);
	        
	        
	        btnNewButton_1 = new JButton("추가");
	        btnNewButton_1.addActionListener(new ActionListener() {
	        	public void actionPerformed(ActionEvent e) {
	        		String str = textField.getText().trim();
	        		alldao.allergy.add(str);
	        		open();
	        		try {
						alldao.close();
					} catch (Exception e1) {
					}
	        	}
	        });
	        btnNewButton_1.setBounds(178, 199, 97, 23);
	        NewWindowContainer.add(btnNewButton_1);
	        
	        textField = new JTextField();
	        textField.setBounds(39, 200, 116, 21);
	        NewWindowContainer.add(textField);
	        textField.setColumns(10);
	        
	        setSize(431,264);
	        setResizable(false);
	        setVisible(true);	
	        }
	public void open() {
		alldao.open();
		list.removeAll();
		list.setListData(alldao.allergy.toArray());
	}

	/**
	 * Initialize the contents of the frame.
	 */
	

}
