package com.ssafy.food;

public class Foodmain {
	public static void main(String[] args) {
		FoodDAO dao = new FoodDAO();
		dao.open();
//		for (Food f : dao.list) {
//			System.out.println(f);
//		}
		System.out.println(dao.searchbyna("국산콩두부두모"));
	}
}
