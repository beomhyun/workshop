package com.ssafy.edu.vue.dto;
//com.ssafy.edu.vue.dto.flagDto
public class flagDto {
	private int code;
	private String name;
	private String flag;
	private String korname;
	public flagDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public flagDto(int code, String name, String flag, String korname) {
		super();
		this.code = code;
		this.name = name;
		this.flag = flag;
		this.korname = korname;
	}
	@Override
	public String toString() {
		return "flagDto [code=" + code + ", name=" + name + ", flag=" + flag + ", korname=" + korname + "]";
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getKorname() {
		return korname;
	}
	public void setKorname(String korname) {
		this.korname = korname;
	}
	
}
